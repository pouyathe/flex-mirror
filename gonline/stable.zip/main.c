#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// The function definition
void systemg(const char* value) {
    char commend[256];
    snprintf(commend, sizeof(commend), "wget %s", value);
    system(commend);
}
