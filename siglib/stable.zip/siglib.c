#include <stdio.h>
#include <stdlib.h>
void signal_get(const char* mj){
	char commend[256];
	sprintf(commend, "sudo killall -9 %s", mj);
	system(commend);
	system("reset");
}
