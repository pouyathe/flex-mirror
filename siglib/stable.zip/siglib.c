#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h> // Needed for stat

// Helper to find PID by Terminal ID (e.g., "pts/1")
pid_t find_pid_by_tty(const char* tty_name) {
    DIR *dir;
    struct dirent *entry;
    pid_t pid = -1;
    char target_path[512];

    dir = opendir("/proc");
    if (dir == NULL) return -1;

    while ((entry = readdir(dir)) != NULL) {
        if (atoi(entry->d_name) > 0) {
            char path[512];
            struct stat stat_buf;

            // Construct path to /proc/[PID]/fd/0
            // fd/0 represents the Standard Input (the terminal)
            snprintf(path, sizeof(path), "/proc/%s/fd/0", entry->d_name);

            // Read where that link points to
            if (readlink(path, target_path, sizeof(target_path)) != -1) {
                // Check if the terminal name matches (e.g., contains "pts/1")
                if (strstr(target_path, tty_name) != NULL) {
                    pid = (pid_t) atoi(entry->d_name);
                    break; 
                }
            }
        }
    }
    closedir(dir);
    return pid;
}

__attribute__((visibility("default")))
void dead_tty(const char* tty_name) {
    pid_t target_pid = find_pid_by_tty(tty_name);

    if (target_pid == -1) {
        printf("[Library] Error: No process found on TTY %s\n", tty_name);
        return;
    }

    printf("[Library] Found process %d on TTY %s. Pausing...\n", target_pid, tty_name);

    if (kill(target_pid, SIGTSTP) == 0) {
        printf("[Library] Success!\n");
    } else {
        perror("[Library] Failed");
    }
}
