#include <stdio.h>
#include <stdlib.h>
void signal_get(const char* mj){
	exit(0);
}
